import java.util.ArrayList;
import java.util.List;

public class InterpreterMilestone3 {

    private TinyPLParser.ProgramContext tree;

    public InterpreterMilestone3(TinyPLParser.ProgramContext tree) {
        this.tree = tree;
    }

    public List<String> run() {
        List<String> output = new ArrayList<>();

        // TODO: add your solution here

        return output;
    }

}
